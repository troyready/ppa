package compat

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"

	DockerClient "github.com/containers/image/v5/docker"
	"github.com/containers/image/v5/types"
	"github.com/containers/podman/v2/pkg/api/handlers/utils"
	"github.com/containers/podman/v2/pkg/domain/entities"
	"github.com/containers/podman/v2/pkg/registries"
	docker "github.com/docker/docker/api/types"
	"github.com/pkg/errors"
)

func Auth(w http.ResponseWriter, r *http.Request) {
	var authConfig docker.AuthConfig
	err := json.NewDecoder(r.Body).Decode(&authConfig)
	if err != nil {
		utils.Error(w, "Something went wrong.", http.StatusInternalServerError, errors.Wrapf(err, "failed to parse request"))
		return
	}

	skipTLS := types.NewOptionalBool(false)
	if strings.HasPrefix(authConfig.ServerAddress, "http://localhost/") || strings.HasPrefix(authConfig.ServerAddress, "http://localhost:") {
		// support for local testing
		skipTLS = types.NewOptionalBool(true)
	}

	fmt.Println("Authenticating with existing credentials...")
	sysCtx := types.SystemContext{
		AuthFilePath:                "",
		DockerCertPath:              "",
		DockerInsecureSkipTLSVerify: skipTLS,
		SystemRegistriesConfPath:    registries.SystemRegistriesConfPath(),
	}
	if err := DockerClient.CheckAuth(context.Background(), &sysCtx, authConfig.Username, authConfig.Password, authConfig.ServerAddress); err == nil {
		utils.WriteResponse(w, http.StatusOK, entities.AuthReport{
			IdentityToken: "",
			Status:        "Login Succeeded",
		})
	} else {
		utils.WriteResponse(w, http.StatusBadRequest, entities.AuthReport{
			IdentityToken: "",
			Status:        "login attempt to " + authConfig.ServerAddress + " failed with status: " + err.Error(),
		})
	}
}
